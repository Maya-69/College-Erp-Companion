# 🎓 VIT College ERP System

A full-stack MERN (MongoDB, Express, React, Node.js) ERP system inspired by Vidyalankar Institute of Technology's student portal.

## ✨ Features

### 👨‍💼 Admin Portal
- **Dashboard** — Stats overview (students, results, documents, events)
- **Student Management** — Add, view, search, delete students
- **Results Management** — Add semester results with subject-wise marks, SGPI, CGPI
- **Documents Management** — Issue official documents to students
- **Events Management** — Schedule events with date, time, venue
- **Notices** — Post announcements with priority levels

### 🎒 Student Portal  
- **Dashboard** — Personalized home with events, holidays, notices, SGPI
- **Results** — Semester-wise result cards with detailed marksheet view
- **Documents** — Download issued documents (Bonafide, Transcripts, etc.)
- **Events & Notices** — View events, holidays, and notices
- **Profile** — View personal details

### 📄 Print / Download
- Results can be printed as official marksheets
- Documents generate printable certificates

---

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- MongoDB (local or MongoDB Atlas)

### 1. Install Dependencies

```bash
# Install server dependencies
cd server
npm install

# Install client dependencies
cd ../client
npm install
```

### 2. Start MongoDB
Make sure MongoDB is running on `mongodb://localhost:27017`

Or set `MONGO_URI` environment variable for Atlas.

### 3. Start the Application

**Terminal 1 — Start Server:**
```bash
cd server
node index.js
```

**Terminal 2 — Start Client:**
```bash
cd client
npm run dev
```

### 4. Seed Demo Data
Open browser at `http://localhost:5173`, click **"🌱 Seed Demo Data"**

### 5. Login with Demo Credentials

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@vit.edu.in | admin123 |
| Student | vicky@vit.edu.in | student123 |

---

## 📁 Project Structure

```
college-erp/
├── server/
│   ├── index.js        # Express server + all routes + models
│   └── package.json
└── client/
    ├── src/
    │   ├── App.jsx             # Router setup
    │   ├── index.css           # Global styles
    │   ├── context/
    │   │   └── AuthContext.jsx # Auth state + API helper
    │   ├── components/
    │   │   └── Navbar.jsx      # Shared navigation
    │   └── pages/
    │       ├── Landing.jsx     # Login page
    │       ├── AdminPortal.jsx # Admin dashboard & management
    │       └── StudentPortal.jsx # Student dashboard & views
    ├── index.html
    ├── package.json
    └── vite.config.js
```

## 🔧 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, React Router v6 |
| Styling | Pure CSS with CSS Variables |
| Backend | Express.js, Node.js |
| Database | MongoDB with Mongoose |
| Auth | JWT (jsonwebtoken) |
| Security | bcryptjs password hashing |

## 🌐 API Endpoints

### Auth
- `POST /api/auth/register` — Register user
- `POST /api/auth/login` — Login

### Students (Admin only for mutations)
- `GET /api/students` — List all students
- `DELETE /api/students/:id` — Delete student

### Results
- `POST /api/results` — Add result (Admin)
- `GET /api/results` — Get results (filtered by role)
- `DELETE /api/results/:id` — Delete result (Admin)

### Documents
- `POST /api/documents` — Issue document (Admin)
- `GET /api/documents` — Get documents
- `DELETE /api/documents/:id` — Delete (Admin)

### Events & Holidays & Notices
- `GET/POST/DELETE /api/events`
- `GET/POST /api/holidays`
- `GET/POST /api/notices`

### Admin
- `GET /api/admin/stats` — Dashboard statistics
- `POST /api/seed` — Seed demo data

## 🔐 Security
- JWT tokens with 7-day expiry
- bcrypt password hashing (10 rounds)
- Role-based access control (admin vs student)
- Protected routes on both frontend and backend
